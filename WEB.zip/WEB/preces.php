<!DOCTYPE html>
  <html>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <head>
    <style>
table {
    width: 100%;
}
td {
    vertical-align: top;
}
.d1 {
    text-align: left;
}
.d2 {
    text-align:center;
}
.d3 {
    text-align:right;
}
.copy {
    visibility: hidden;
}
.copy, .d3 {
    white-space: nowrap;
}
@media print {
  body * {
    visibility: hidden;
  }
  .print-container, .print-container * {
    visibility: visible;
  }
}

    </style>
    	<link rel="shortcut icon" href="https://images.vexels.com/media/users/3/128132/isolated/preview/fa3b9aad78a9db81459bd03294a0f985-flat-laptop-icon-design-by-vexels.png">
        <title> Laptop piedavajumi </title>
        <?php include "upgrade.php" ?>
   <body background="https://wallpaper.dog/large/5486750.png">
    </head>
    <button class="btn" id="print2" onClick="window.print()">Printēt lapu</button><br><br>
    <div class="row print-container">
    <h3><table>
    <tr>
        <td style="text-align: center" class="d1">
            Informācijas centrs:<br>+37123234545
        </td>
        <td style="text-align: center" class="d2">
            Komanda:<br>
Linards Zariņš | Madara Bogdānova |<br>
Kārlis Rozenbergs<br>
Evita Dreimane | Nils Kuģis |
        </td>
        <td style="text-align: center" class="d3">Kantakt informācija:<br>
inf@laptop.lv<br>
+37120216789right text</td>
    </tr>
</table></h3><br><br><div>

     <br>
    </body>
    </html>